import { Injectable } from '@angular/core';
import { delay, Observable, of, timer } from 'rxjs';
import { Mission } from '../dataTypes/mission';
import { MissionImage } from '../dataTypes/missionImage';
import { Tag } from '../dataTypes/tag';

@Injectable({
  providedIn: 'root'
})
export class FakeServerService {

  constructor() { }

  GetMissions() : Mission[] {
    return this.RecordToArray(this.missions);
  }

  GetImageData(missionId : string , imageId: string): Observable<MissionImage> {
    const res = this.missions[missionId].missionImages
        .filter(mission => mission.imageId == imageId)[0];
    return this.ReturnFakeAsyncOf(res);
  }

  GetMissionData(id: string): Observable<Mission> {
    return this.ReturnFakeAsyncOf(this.missions[id],50);
  }

  CompleteImage(imageId: string): Observable<boolean> {
    return this.ReturnFakeAsyncOf(true);
  }

  //#region Private Methods

  private ReturnFakeAsyncOf<Type>(value : Type , delayMili : number = 3000) : Observable<Type> {
    return of(value).pipe(delay(delayMili));
  } 

  private RecordToArray<ValueType>(record : Record<string,ValueType>){
    const array : ValueType[] = [];
    for(const key in this.missions){
      array.push(record[key]);
    }
    return array;
  } 

  //#endregion

  private missions: Record<string, Mission> = {
    ["1"]: {
      missionId: "1",
      missionImages: [
        {
          imageId: "11",
          address: "/assets/images/image.jpg",
          tags: [ 
          {x : 150 , y : 50 , radius : 30 , id :3}
          ],
          texts: [
            { content : "123eden" , x : 200 , y : 50 , id : 5}
          ]
        },
        {
          imageId: "12",
          address: "/assets/images/LythrumSalicaria-flower-1mb.jpg",
          tags: [ ],
          texts: [  ]
        },
        {
          imageId: "13",
          address: "/assets/images/pexels-photo-2440079.jpeg",
          tags: [ ],
          texts: [  ]
        }

      ]
    },
    ["2"]: {
      missionId: "2",
      missionImages: [
        {
          imageId: "21",
          address: "/assets/images/andromeda_1920x1200.jpg",
          tags: [ ],
          texts: [  ]
        },
        {
          imageId: "22",
          address: "https://upload.wikimedia.org/wikipedia/commons/thumb/4/41/Sunflower_from_Silesia2.jpg/1200px-Sunflower_from_Silesia2.jpg",
          tags: [ ],
          texts: [  ]
        },
        {
          imageId: "23",
          address: "https://upload.wikimedia.org/wikipedia/commons/thumb/4/41/Sunflower_from_Silesia2.jpg/1200px-Sunflower_from_Silesia2.jpg",
          tags: [ ],
          texts: [  ]
        }

      ]
    }
  };
}
