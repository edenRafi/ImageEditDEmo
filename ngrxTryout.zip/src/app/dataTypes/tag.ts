export interface Tag {
    x: number;
    y: number;
    radius: number;
    id: number;
}