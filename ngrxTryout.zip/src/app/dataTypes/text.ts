export interface ImageText {
    content : string;
    x : number;
    y : number;
    id : number;
}