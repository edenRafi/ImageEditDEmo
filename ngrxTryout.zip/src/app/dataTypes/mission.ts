import { MissionImage } from "./missionImage";

export interface Mission {
    missionId : string;
    missionImages : MissionImage[];
}