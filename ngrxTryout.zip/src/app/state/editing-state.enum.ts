export enum EditingState {
    NA,
    normal,
    tag,
    text
}