export interface RotationState {
    currentImageRotation : number;
    rotationAxis : { x : number ,y : number};
}