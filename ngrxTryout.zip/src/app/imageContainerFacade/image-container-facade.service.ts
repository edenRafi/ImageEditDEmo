import { Injectable } from '@angular/core';
import { fabric } from 'fabric';
import { Tag } from '../dataTypes/tag';
import * as FabricTag from '../dataTypes/fabricJSTypes/fabricTag';
import * as FabricText from '../dataTypes/fabricJSTypes/fabricText';
import { Store } from '@ngrx/store';
import { getTagsListFeatureState, getImageAddressFeatureState , getTextsFeatureState, getImageIdFeatureState } from 'src/app/selectors/selectors';
import { ImageText } from '../dataTypes/text';

import * as ImageActions from '../actions/imageActions';
import { FabricObjectContainer } from '../dataTypes/fabricJSTypes/FabricObjectContainer';

@Injectable({
  providedIn: 'root'
})
export class ImageContainerFacadeService {

  canvas: any = null;

  //image: fabric.Image | null = null;

  imageId : string | null = null;

  fabricImage : FabricObjectContainer<fabric.Image> | null = null;

  fabricObjects : FabricObjectContainer<fabric.Object>[] = [];

  tags = null;

  texts = null;

  brightnessFilter : fabric.IBrightnessFilter = new fabric.Image.filters.Brightness();

  currentRotation : number = 0;

  currenrRtoationAxis : fabric.Point | null = null;

  sharpnessFilter = new fabric.Image.filters.Convolute({
    matrix: [ 0, -1,  0,
             -1,  5, -1,
              0, -1,  0 ]
  });

  lastPosX : number = 0;
  lastPosY : number = 0;
  isDragging : boolean = false;
  viewportTransform : number[] | undefined = [];


  constructor(private store: Store<any>) {

    this.store.select(getTagsListFeatureState).subscribe(tags =>
      tags?.forEach(tag => this.addTag(tag))
    );

    this.store.select(getTextsFeatureState).subscribe(texts =>
      texts?.forEach(text => this.addText(text)));

    this.store.select(getImageIdFeatureState).subscribe(imageId =>
      this.imageId = imageId)

    this.store.select(getImageAddressFeatureState).subscribe(
      async address => {
      if(address) await this.loadImage(address);
      }
    );
  }

  initCanvas(canvas: fabric.Canvas) {
    this.canvas = canvas;
    canvas.selection = false;

    this.viewportTransform = (<fabric.Canvas>(this.canvas)).viewportTransform;

    canvas.on('mouse:wheel', (mouseEvent : any) => {
      var delta = mouseEvent.e.deltaY;
      var zoom = canvas.getZoom();
      zoom *= 0.999 ** delta;
      if (zoom > 20) zoom = 20;
      if (zoom < 0.01) zoom = 0.01;
      canvas.zoomToPoint({ x: mouseEvent.e.offsetX, y: mouseEvent.e.offsetY }, zoom);
      mouseEvent.e.preventDefault();
      mouseEvent.e.stopPropagation();
    });

    this.canvas.on('mouse:down',(mouseEvent : any) => {
      var evt = mouseEvent.e;
      if (evt.altKey === true) {
        this.isDragging = true;
        this.lastPosX = evt.clientX;
        this.lastPosY = evt.clientY;
      }
    });
    canvas.on('mouse:move', (mouseEvent : any) =>  {
      if (this.isDragging) {
        var e = mouseEvent.e;
        var vpt = this.viewportTransform;
        (<number[]>vpt)[4] += e.clientX - this.lastPosX;
        (<number[]>vpt)[5] += e.clientY - this.lastPosY;
        canvas.requestRenderAll();
        this.lastPosX = e.clientX;
        this.lastPosY = e.clientY;
      }
    });
    canvas.on('mouse:up', (mouseEvent : any) =>  {
      this.canvas.setViewportTransform(this.viewportTransform);
      this.isDragging = false;
      canvas.selection = true;
    });
    this.RegisterToMouseClicksInTags();
  }

  applyBrightness(brightness : number){
    var filters = <fabric.IBaseFilter[]>(this.fabricImage?.innerFabricObject?.filters);
    var brightnessFilter = <fabric.IBrightnessFilter>filters[0];
    brightnessFilter.setOptions({brightness : brightness});
    this.fabricImage?.innerFabricObject?.applyFilters();
    this.canvas.renderAll();
  }

  applySharpness(sharpness : number){
    var filters = <fabric.IBaseFilter[]>(this.fabricImage?.innerFabricObject?.filters);
    var sharpnessFilter = <fabric.IBrightnessFilter>filters[1];
    const newMatrix = [ 0             ,-1 * sharpness  ,         0,
                        -1 * sharpness, 1 + 4 *sharpness, -1 * sharpness,
                        0             , -1 * sharpness  ,  0              ]
    sharpnessFilter.setOptions({matrix : newMatrix});
    this.fabricImage?.innerFabricObject?.applyFilters();
    this.canvas.renderAll();
  }

  //#region State Changing Methods

  SetEditStateToTagState() {
    this.store.dispatch(ImageActions.TagStateNotDrawing());
  }

  SetEditStateToTextState() {
    throw new Error('Method not implemented.');
  }

  //#endregion

  //#region Private Methods

  private loadImage(url: string): Promise<boolean> {
    return new Promise((resolve, reject) => {
      if(!url) {
        reject("url is null");
      }

      fabric.Image.fromURL(url,
      (img) => {

        if(img == null) reject("failed to load image");

        this.fabricObjects.forEach(fabObj => this.canvas.remove(fabObj.innerFabricObject));
        this.fabricObjects = [];
        if (this.fabricImage != null) this.canvas.remove(<fabric.Image>(this.fabricImage?.innerFabricObject));

        img.selectable = false;
        this.canvas.add(img);
        this.currenrRtoationAxis = new fabric.Point( <number>(img.width) / 2, <number>(img.height) / 2);
        this.fabricImage = new FabricObjectContainer
        (0,<number>(img.left),<number>(img.top),img,0,this.currenrRtoationAxis.x,this.currenrRtoationAxis.y);

        this.fabricImage?.innerFabricObject?.filters?.push(this.brightnessFilter);
        this.fabricImage?.innerFabricObject?.filters?.push(this.sharpnessFilter);

        this.canvas.renderAll();
        resolve(true);
      });
    });
  }

  private addTag(tag: Tag) {
    var fabricTag = new FabricTag.FabricTag({
      left: tag.x,
      top: tag.y,
      radius: tag.radius,
      stroke: 'red',
      strokeWidth: 3,
      fill: '',
      originalId: tag.id
    });
    fabricTag.selectable = false;
    fabricTag.centeredRotation = false
    this.canvas.add(fabricTag);
    this.canvas.renderAll();

    const imageCenter = <fabric.Point>this.currenrRtoationAxis;
    this.fabricObjects.push(new FabricObjectContainer(tag.id,0,0,fabricTag
      ,this.currentRotation,imageCenter.x,imageCenter.y));
  }

  private addText(text: ImageText) {
    var fabricText = new FabricText.FabricText(text.content,{
      left: text.x,
      top: text.y,
      originalId: text.id
    });
    fabricText.selectable = false;
    this.canvas.add(fabricText);
    this.canvas.renderAll();

    const imageCenter = <fabric.Point>this.currenrRtoationAxis;
    this.fabricObjects.push(new FabricObjectContainer(text.id,0,0,fabricText
      ,this.currentRotation,imageCenter.x,imageCenter.y));
  }

  //#endregion

  //#region RegisterToEvents

  onTagsState = (mouseEvent : any) => {
    const event = <MouseEvent>(mouseEvent.e);
    console.log(`(${event.x - event.pageX},${event.y - event.pageY})`);
    this.canvas.off('mouse:down',this.onTagsState)
  }

  RegisterToMouseClicksInTags(){
    this.canvas.on('mouse:down',this.onTagsState);
  }
  //#endregion

    
  rotateAroundImageCenter(degrees : number){
    const imageCenter = <fabric.Point>this.currenrRtoationAxis;
    let radians = fabric.util.degreesToRadians(degrees);

    this.fabricObjects.concat(<FabricObjectContainer<fabric.Object>>(this.fabricImage)).forEach(fabricOBject => {
      let innerFabricObject = fabricOBject.innerFabricObject;
      let objectOrigin = new fabric.Point(fabricOBject.originX, fabricOBject.originY);
      let newLocation = fabric.util.rotatePoint(objectOrigin, imageCenter, radians);
      (<fabric.Object>innerFabricObject).top = newLocation.y;
      (<fabric.Object>innerFabricObject).left = newLocation.x;
      (<fabric.Object>innerFabricObject).angle = degrees;
      (<fabric.Object>innerFabricObject)?.setCoords();
    });

    this.canvas.renderAll();
  }

}
